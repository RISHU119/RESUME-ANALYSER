
import React from 'react';

export function Header(): React.ReactNode {
    return (
        <header className="bg-white dark:bg-slate-800/50 backdrop-blur-sm shadow-sm sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700">
            <div className="max-w-4xl mx-auto p-4 flex items-center gap-4">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                    <path fillRule="evenodd" d="M8.25 6.75a3.75 3.75 0 1 1 7.5 0 3.75 3.75 0 0 1-7.5 0ZM15.75 9.75a.75.75 0 0 0-1.5 0v.25a.75.75 0 0 0 1.5 0v-.25ZM12.75 9a.75.75 0 0 1 .75-.75h.01a.75.75 0 0 1 .75.75v.01a.75.75 0 0 1-.75.75h-.01a.75.75 0 0 1-.75-.75v-.01ZM10.5 9.75a.75.75 0 0 0-1.5 0v.25a.75.75 0 0 0 1.5 0v-.25Z" clipRule="evenodd" />
                    <path d="M5.22 13.62a.75.75 0 0 0-1.06 1.06l1.25 1.25a.75.75 0 0 0 1.06 0l1.25-1.25a.75.75 0 0 0-1.06-1.06L6 14.06l-.78-.44Z" />
                    <path d="M18.78 13.62a.75.75 0 0 0-1.06-1.06l-.78.44 1.25 1.25a.75.75 0 0 0 1.06 0l1.25-1.25a.75.75 0 0 0-1.06-1.06L18 14.06Z" />
                    <path fillRule="evenodd" d="M15.53 15.65A.75.75 0 0 1 16 16.5v.69l-1.22-1.22-.25.13ZM8.47 15.65a.75.75 0 0 0-.47.85v.69l1.22-1.22-.25.13Z" clipRule="evenodd" />
                    <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM6.23 18.32a.75.75 0 0 1 .75-.04l.5.25a.75.75 0 0 1 0 1.34l-1.25.63a.75.75 0 0 1-.94-.94l1.25-1.25a.75.75 0 0 1 .31-.22l.38-.19Zm8.25-1.34.5-.25a.75.75 0 0 1 .75.04l.38.19.31.22 1.25 1.25a.75.75 0 0 1-.94.94l-1.25-.63a.75.75 0 0 1 0-1.34Z" clipRule="evenodd" />
                 </svg>
                <h1 className="text-xl font-bold text-slate-900 dark:text-white">Resume Analyzer</h1>
            </div>
        </header>
    );
}
