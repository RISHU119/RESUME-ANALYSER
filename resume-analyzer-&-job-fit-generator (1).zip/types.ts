
export interface JobSuggestion {
    title: string;
    reason: string;
}
