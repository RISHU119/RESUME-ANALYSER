
import React from 'react';
import type { JobSuggestion } from '../types';

interface JobSuggestionsProps {
    suggestions: JobSuggestion[];
}

export function JobSuggestions({ suggestions }: JobSuggestionsProps): React.ReactNode {
    return (
        <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">AI-Powered Suggestions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {suggestions.map((suggestion, index) => (
                    <div key={index} className="bg-slate-100 dark:bg-slate-700/50 p-5 rounded-lg border border-slate-200 dark:border-slate-700 transform hover:scale-105 transition-transform duration-300">
                        <h4 className="font-bold text-lg text-indigo-600 dark:text-indigo-400 mb-2">{suggestion.title}</h4>
                        <p className="text-slate-600 dark:text-slate-300 text-sm">{suggestion.reason}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}
