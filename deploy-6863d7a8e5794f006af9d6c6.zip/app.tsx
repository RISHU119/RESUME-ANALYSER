
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { JobSuggestions } from './components/JobSuggestions';
import { Loader } from './components/Loader';
import { ErrorAlert } from './components/ErrorAlert';
import { analyzeResume } from './services/geminiService';
import type { JobSuggestion } from './types';

// Let TypeScript know pdfjsLib is available on the global scope from the CDN script
declare var pdfjsLib: any;

export default function App(): React.ReactNode {
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [jobSuggestions, setJobSuggestions] = useState<JobSuggestion[] | null>(null);

    useEffect(() => {
        // Set the workerSrc for pdf.js. This is required for it to work correctly.
        if (typeof pdfjsLib !== 'undefined') {
            pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.worker.min.mjs`;
        }
    }, []);

    const handleFileSelect = (selectedFile: File | null) => {
        if (selectedFile) {
            setFile(selectedFile);
            setFileName(selectedFile.name);
            setJobSuggestions(null);
            setError(null);
        }
    };
    
    const parsePdf = useCallback(async (fileToParse: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = async (event) => {
                if (!event.target?.result) {
                    return reject(new Error("Failed to read file."));
                }
                try {
                    const pdf = await pdfjsLib.getDocument(event.target.result).promise;
                    let textContent = '';
                    for (let i = 1; i <= pdf.numPages; i++) {
                        const page = await pdf.getPage(i);
                        const text = await page.getTextContent();
                        textContent += text.items.map((s: any) => s.str).join(' ');
                    }
                    resolve(textContent);
                } catch (pdfError) {
                    console.error("PDF Parsing Error:", pdfError);
                    reject(new Error("Could not parse the PDF file. Please ensure it's a valid, text-based PDF."));
                }
            };
            reader.onerror = () => {
                reject(new Error("Error reading file."));
            };
            reader.readAsArrayBuffer(fileToParse);
        });
    }, []);

    const handleAnalyzeClick = async () => {
        if (!file) {
            setError("Please select a file first.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setJobSuggestions(null);

        try {
            const resumeText = await parsePdf(file);
            if (!resumeText.trim()) {
                throw new Error("Could not extract any text from the PDF. It might be an image-based PDF.");
            }
            const suggestions = await analyzeResume(resumeText);
            setJobSuggestions(suggestions);
        } catch (e: any) {
            setError(e.message || "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans">
            <Header />
            <main className="max-w-4xl mx-auto p-4 md:p-8">
                <div className="text-center mb-8">
                    <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">Unlock Your Career Potential</h2>
                    <p className="text-slate-600 dark:text-slate-400 mt-2 max-w-2xl mx-auto">
                        Upload your PDF resume, and our AI will analyze its content to suggest relevant job titles and industries tailored to your profile.
                    </p>
                </div>

                <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 md:p-8 border border-slate-200 dark:border-slate-700">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <FileUpload onFileSelect={handleFileSelect} fileName={fileName} />
                        <button
                            onClick={handleAnalyzeClick}
                            disabled={!file || isLoading}
                            className="w-full sm:w-auto flex-shrink-0 bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 focus:ring-offset-white dark:focus:ring-offset-slate-800 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors duration-200"
                        >
                            {isLoading ? 'Analyzing...' : 'Analyze Resume'}
                        </button>
                    </div>

                    <div className="mt-8">
                        {isLoading && <Loader />}
                        {error && <ErrorAlert message={error} />}
                        {jobSuggestions && <JobSuggestions suggestions={jobSuggestions} />}
                    </div>
                </div>
                 <footer className="text-center mt-12 text-sm text-slate-500 dark:text-slate-400">
                    <p>Powered by Google Gemini. Please review AI-generated suggestions carefully.</p>
                </footer>
            </main>
        </div>
    );
}
